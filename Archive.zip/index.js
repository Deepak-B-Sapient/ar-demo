const startPanel = document.getElementsByClassName("startPanel")[0];
const startButton = document.getElementById("btn");
const videoWrapper = document.getElementById("video");
const videoObj = document.getElementById("vid");
startButton.addEventListener("click", () => {
  startPanel.classList.add("hide");
});
